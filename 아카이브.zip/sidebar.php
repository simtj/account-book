            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                     
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> 거래처 관리</a>
                        </li>
                        <li>
                            <a href="gyeolsan.php"><i class="fa fa-dashboard fa-fw"></i> 결산 관리</a>
                        </li>
                        <li>
                            <a href="wolbyeol_list.php"><i class="fa fa-dashboard fa-fw"></i> 월별 리스트</a>
                        </li>
                        <li>
                            <a href="ilbyeol_list.php"><i class="fa fa-dashboard fa-fw"></i> 일별 입력 리스트</a>
                        </li>                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->